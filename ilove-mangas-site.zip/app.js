
const apiEndpoint = "https://manga-api.example.com"; // API fictícia para dados dinâmicos
let currentManga = '';
let currentChapter = 1;
let currentPage = 1;

async function loadMangas() {
  const response = await fetch(`${apiEndpoint}/mangas`);
  const mangas = await response.json();
  const main = document.getElementById('main');
  main.innerHTML = mangas.map(manga => `
    <div class="manga" data-id="${manga.id}" onclick="openChapters('${manga.id}')">
      <img src="${manga.cover}" alt="${manga.title}">
      <p>${manga.title}</p>
    </div>
  `).join('');
}

function searchManga() {
  const input = document.getElementById('searchInput').value.toLowerCase();
  const mangaCards = document.querySelectorAll('.manga');
  mangaCards.forEach(card => {
    const title = card.querySelector('p').textContent.toLowerCase();
    card.style.display = title.includes(input) ? 'block' : 'none';
  });
}

async function openChapters(mangaId) {
  currentManga = mangaId;
  const response = await fetch(`${apiEndpoint}/mangas/${mangaId}`);
  const manga = await response.json();
  const chapters = manga.chapters;
  let html = `<h2>${manga.title}</h2>`;
  for (const chapter of chapters) {
    html += `<div class="chapter" onclick="openChapter(${chapter.id})">Capítulo ${chapter.number}</div>`;
  }
  document.getElementById('chapters').innerHTML = html;
  document.getElementById('main').style.display = 'none';
  document.getElementById('chapters').style.display = 'flex';
}

async function openChapter(chapterId) {
  currentChapter = chapterId;
  currentPage = 1;
  document.getElementById('chapters').style.display = 'none';
  document.getElementById('reader').style.display = 'flex';
  updatePage();
}

async function updatePage() {
  const response = await fetch(`${apiEndpoint}/chapters/${currentChapter}/pages/${currentPage}`);
  const pageData = await response.json();
  document.getElementById('page').src = pageData.image;
}

function nextPage() {
  currentPage++;
  updatePage();
}

function prevPage() {
  if (currentPage > 1) {
    currentPage--;
    updatePage();
  }
}

function goBackToChapters() {
  document.getElementById('reader').style.display = 'none';
  document.getElementById('chapters').style.display = 'flex';
}

function submitComment() {
  const input = document.getElementById('commentInput');
  const commentList = document.getElementById('commentList');
  if (input.value.trim()) {
    const li = document.createElement('li');
    li.textContent = input.value;
    commentList.appendChild(li);
    input.value = '';
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadMangas();
});
